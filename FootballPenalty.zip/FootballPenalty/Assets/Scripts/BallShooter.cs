using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;
using TMPro;                                        // BONUS B
public class BallShooter : MonoBehaviour
{
    [Header("References")]
    public Transform crosshair;
    public Slider powerSlider;
    public TMP_Text curveText;                      // BONUS B
    [Header("Shooting")]
    public float maxForce = 14f;      // kick strength at full power
    public float chargeTime = 1.2f;   // seconds to fill the gauge
    public float minPower = 0.15f;    // below this the shot is cancelled
    [Header("Curve")]
    public float curveStrength = 6f;                // BONUS B: bigger = more bend
    [Header("Miss detection")]
    public float stopSpeed = 0.3f;    // slower than this = ball stopped
    public float maxY = 5.5f;         // ball went over the top
    public float maxX = 9.5f;         // ball went out of the side
    public float resetDelay = 1.5f;   // wait before the next shot
    [Header("Extras")]
    public float netDamping = 6f;         // how strongly the net slows the ball
    public float keeperSpeedBonus = 0.4f; // keeper gets faster after each goal
    private Rigidbody2D rb;
    private Camera cam;
    private Goalkeeper keeper;
    private Vector2 startPos;
    private float normalDamping;
    private float power;
    private int curveMode = 0;                      // BONUS B: -1 left, 0 straight, 1 right
    private bool charging;
    private bool shotFired;
    private bool resolved;
    private float shotTimer;
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        cam = Camera.main;
        keeper = FindFirstObjectByType<Goalkeeper>();
        startPos = rb.position;
        normalDamping = rb.linearDamping;
        powerSlider.value = 0f;
        UpdateCurveText();                          // BONUS B
    }
    void Update()
    {
        if (!GameManager.Instance.IsPlaying) return;
        Mouse mouse = Mouse.current;
        if (mouse == null) return;
        Vector2 mouseWorld = cam.ScreenToWorldPoint(mouse.position.ReadValue());
        crosshair.position = mouseWorld;
        if (!shotFired)
        {
            HandleAimAndCharge(mouse, mouseWorld);
        }
        else if (!resolved)
        {
            CheckForMiss();
        }
    }
    // BONUS B: the curve force is applied in FixedUpdate (physics time)
    void FixedUpdate()
    {
        if (!shotFired || resolved || curveMode == 0) return;
        Vector2 v = rb.linearVelocity;
        if (v.magnitude < 0.5f) return;
        Vector2 left = new Vector2(-v.y, v.x).normalized;    // 90 degrees to the left
        rb.AddForce(left * (-curveMode * curveStrength));    // right = -left
    }
    void HandleAimAndCharge(Mouse mouse, Vector2 mouseWorld)
    {
        // BONUS B: right click cycles Straight -> Right -> Left -> Straight
        if (mouse.rightButton.wasPressedThisFrame && !charging)
        {
            if (curveMode == 0) curveMode = 1;
            else if (curveMode == 1) curveMode = -1;
            else curveMode = 0;
            UpdateCurveText();
        }
        // press = start charging
        if (mouse.leftButton.wasPressedThisFrame)
        {
            charging = true;
            power = 0f;
        }
        // hold = gauge fills

        if (charging && mouse.leftButton.isPressed)
        {
            power += Time.deltaTime / chargeTime;
            power = Mathf.Clamp01(power);
            powerSlider.value = power;
        }
        // release = shoot
        if (charging && mouse.leftButton.wasReleasedThisFrame)
        {
            charging = false;
            if (power < minPower)
            {
                power = 0f;
                powerSlider.value = 0f;
                return;
            }
            Shoot(mouseWorld);
        }
    }
    void Shoot(Vector2 target)
    {
        Vector2 direction = target - rb.position;
        direction.y = Mathf.Max(direction.y, 0.2f);   // always shoot forward
        direction.Normalize();
        // tell the keeper where the (straight) ball would cross the goal line
        if (keeper != null)
        {
            float t = (keeper.transform.position.y - rb.position.y) / direction.y;
            float goalX = rb.position.x + direction.x * t;
            keeper.OnShot(goalX);
        }
        rb.AddForce(direction * (power * maxForce), ForceMode2D.Impulse);
        shotFired = true;
        shotTimer = 0f;
        GameManager.Instance.UseAttempt();
        if (SoundManager.Instance != null) SoundManager.Instance.PlayKick();
    }
    void CheckForMiss()
    {
        shotTimer += Time.deltaTime;
        bool outOfBounds = rb.position.y > maxY || Mathf.Abs(rb.position.x) > maxX;
        bool stopped = shotTimer > 0.5f && rb.linearVelocity.magnitude < stopSpeed;
        bool tookTooLong = shotTimer > 6f;
        if (outOfBounds || stopped || tookTooLong)
        {
            Resolve("MISSED!");
        }
    }
    // called by GoalZone when the ball enters the net
    public void OnGoal()
    {
        if (!shotFired || resolved) return;
        resolved = true;
        rb.linearDamping = netDamping;   // the net catches the ball
        GameManager.Instance.AddGoal();
        if (SoundManager.Instance != null) SoundManager.Instance.PlayGoal();
        if (keeper != null) keeper.speed += keeperSpeedBonus;
        Invoke(nameof(ResetBall), resetDelay);
    }
    // called by Unity when the ball hits something solid
    void OnCollisionEnter2D(Collision2D collision)
    {
        if (!shotFired || resolved) return;
        if (collision.gameObject.GetComponent<Goalkeeper>() != null)
        {
            if (SoundManager.Instance != null) SoundManager.Instance.PlaySave();
            Resolve("SAVED!");
        }
    }
    void Resolve(string message)
    {
        resolved = true;
        GameManager.Instance.ShowMessage(message);
        Invoke(nameof(ResetBall), resetDelay);
    }
    void ResetBall()
    {
        rb.linearVelocity = Vector2.zero;
        rb.angularVelocity = 0f;
        rb.position = startPos;
        rb.rotation = 0f;
        rb.linearDamping = normalDamping;
        power = 0f;
        powerSlider.value = 0f;
        charging = false;
        shotFired = false;
        resolved = false;
        curveMode = 0;                              // BONUS B: back to a straight shot
        UpdateCurveText();
        if (keeper != null) keeper.ResetKeeper();
        GameManager.Instance.CheckEnd();
    }
    // BONUS B: shows the current curve on screen
    void UpdateCurveText()
    {
        if (curveText == null) return;
        if (curveMode == 0) curveText.text = "Curve: Straight";
        else if (curveMode > 0) curveText.text = "Curve: Right >>";
        else curveText.text = "<< Curve: Left";
    }
}