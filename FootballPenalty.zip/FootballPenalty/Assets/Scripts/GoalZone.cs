using UnityEngine;
public class GoalZone : MonoBehaviour
{
    // Unity calls this when something enters the trigger area
    void OnTriggerEnter2D(Collider2D other)
    {
        BallShooter ball = other.GetComponent<BallShooter>();
        if (ball != null)
        {
            ball.OnGoal();
        }
    }
}