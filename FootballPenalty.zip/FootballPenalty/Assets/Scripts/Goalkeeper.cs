using UnityEngine;
[RequireComponent(typeof(Rigidbody2D))]
public class Goalkeeper : MonoBehaviour
{
    [Header("Idle patrol")]
    public float speed = 3f;         // patrol speed before the shot
    public float minX = -2.3f;       // left limit
    public float maxX = 2.3f;        // right limit
    public float pauseTime = 0.3f;   // small rest between moves
    [Header("Dive")]
    public float diveSpeed = 8f;     // how fast he dives
    [Range(0f, 1f)]
    public float smartChance = 0.5f; // 0 = pure luck, 1 = always the right side
    public float reactionDelay = 0.15f;
    private enum State { Idle, Diving }
    private Rigidbody2D rb;
    private State state = State.Idle;
    private float targetX;
    private float waitTimer;
    private float reactTimer;
    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
    }
    void Start()
    {
        PickNewTarget();
    }
    void FixedUpdate()
    {
        if (state == State.Diving)
        {
            // wait for the reaction time, then dive
            if (reactTimer > 0f)
            {
                reactTimer -= Time.fixedDeltaTime;
                return;
            }
            MoveToward(diveSpeed);
            return;
        }
        // Idle patrol
        if (waitTimer > 0f)
        {

            waitTimer -= Time.fixedDeltaTime;
            return;
        }
        if (MoveToward(speed))
        {
            waitTimer = pauseTime;
            PickNewTarget();
        }
    }
    // returns true when the keeper has arrived at targetX
    bool MoveToward(float moveSpeed)
    {
        float newX = Mathf.MoveTowards(rb.position.x, targetX, moveSpeed * Time.fixedDeltaTime);
        rb.MovePosition(new Vector2(newX, rb.position.y));
        return Mathf.Approximately(newX, targetX);
    }
    void PickNewTarget()
    {
        targetX = Random.Range(minX, maxX);
    }
    // called by BallShooter when the ball is kicked. goalX = where the ball will cross the goal
    public void OnShot(float goalX)
    {
        if (state == State.Diving) return;
        state = State.Diving;
        reactTimer = reactionDelay;
        // the 3 dive spots: left, centre, right
        float[] spots = { minX, 0f, maxX };
        if (Random.value < smartChance)
        {
            // smart dive: choose the spot closest to the ball's path
            float best = spots[0];
            foreach (float s in spots)
            {
                if (Mathf.Abs(s - goalX) < Mathf.Abs(best - goalX)) best = s;
            }
            targetX = best;
        }
        else
        {
            // random dive (like the Pos array in the video)
            targetX = spots[Random.Range(0, spots.Length)];
        }
    }
    // called by BallShooter when the next shot starts
    public void ResetKeeper()
    {
        state = State.Idle;
        waitTimer = 0f;
        PickNewTarget();
    }
}
