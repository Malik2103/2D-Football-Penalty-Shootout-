using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;
public class GameManager : MonoBehaviour
{
 public static GameManager Instance;
 [Header("Rules")]
 public int totalAttempts = 5;
 public int goalsToWin = 3;
 public float matchTime = 60f;
 [Header("UI")]
 public TMP_Text scoreText;
 public TMP_Text attemptsText;
 public TMP_Text timerText;
 public TMP_Text messageText;
 public GameObject winPanel;
 public GameObject losePanel;
 public GameObject startPanel; // NEW
 private int score;
 private int attemptsUsed;
 private float timeLeft;
 private bool isPlaying = false; // CHANGED: waits for the PLAY button
 private Coroutine messageRoutine;
 // NEW: true after "Play Again" so the start screen is skipped once
 private static bool skipMenu = false;
 public bool IsPlaying { get { return isPlaying; } }
 void Awake()
 {
 Instance = this;
 }
 void Start()
 {
 timeLeft = matchTime;
 winPanel.SetActive(false);
 losePanel.SetActive(false);
 messageText.text = "";
 UpdateUI();
 // NEW: show the start screen, or go straight into the match
 bool skip = skipMenu;
 skipMenu = false;
 if (skip || startPanel == null)

 {
 StartGame();
 }
 else
 {
 startPanel.SetActive(true);
 Cursor.visible = true;
 }
 }
 // NEW: connected to the PLAY button
 public void StartGame()
 {
 if (startPanel != null) startPanel.SetActive(false);
 timeLeft = matchTime;
 isPlaying = true;
 Cursor.visible = false;
 }
 void Update()
 {
 if (!isPlaying) return;
 timeLeft -= Time.deltaTime;
 if (timeLeft <= 0f)
 {
 timeLeft = 0f;
 EndGame();
 }
 UpdateUI();
 }
 // called when a shot is taken
 public void UseAttempt()
 {
 attemptsUsed++;
 UpdateUI();
 }
 // called when the ball enters the net
 public void AddGoal()
 {
 if (!isPlaying) return;
 score++;
 ShowMessage("GOAL!");
 UpdateUI();
 }
 // shows a big message for a short time
 public void ShowMessage(string message)
 {
 if (messageRoutine != null) StopCoroutine(messageRoutine);

 messageRoutine = StartCoroutine(MessageRoutine(message));
 }
 IEnumerator MessageRoutine(string message)
 {
 messageText.text = message;
 yield return new WaitForSeconds(1.2f);
 messageText.text = "";
 }
 // called after every shot is finished
 public void CheckEnd()
 {
 if (isPlaying && attemptsUsed >= totalAttempts)
 {
 EndGame();
 }
 }
 void EndGame()
 {
 Cursor.visible = true;
 isPlaying = false;
 if (SoundManager.Instance != null) SoundManager.Instance.PlayWhistle();
 if (score >= goalsToWin)
 {
 winPanel.SetActive(true);
 }
 else
 {
 losePanel.SetActive(true);
 }
 }
 void UpdateUI()
 {
 scoreText.text = "Goals: " + score;
 attemptsText.text = "Shots: " + attemptsUsed + " / " + totalAttempts;
 timerText.text = "Time: " + Mathf.CeilToInt(timeLeft);
 }
 // connected to the Play Again buttons
 public void Restart()
 {
 skipMenu = true; // NEW: no start screen the next time
 SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
 }
}