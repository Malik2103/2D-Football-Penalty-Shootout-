using UnityEngine;

public class SoundManager : MonoBehaviour
{
    public static SoundManager Instance;

    public AudioClip kickSound;
    public AudioClip goalSound;
    public AudioClip saveSound;
    public AudioClip whistleSound;

    [Tooltip("The goal sound stops after this many seconds")]
    public float goalSoundTime = 3f;

    private AudioSource source;       // kick, save, whistle
    private AudioSource goalSource;   // only for the goal sound

    void Awake()
    {
        Instance = this;

        source = GetComponent<AudioSource>();
        if (source == null) source = gameObject.AddComponent<AudioSource>();

        // separate player only for the goal sound
        goalSource = gameObject.AddComponent<AudioSource>();
        goalSource.playOnAwake = false;
        goalSource.loop = false;
    }

    public void PlayKick()    { Play(kickSound); }
    public void PlaySave()    { Play(saveSound); }
    public void PlayWhistle() { Play(whistleSound); }

    public void PlayGoal()
    {
        if (goalSound == null) return;

        CancelInvoke(nameof(StopGoalSound));
        goalSource.Stop();
        goalSource.loop = false;
        goalSource.clip = goalSound;
        goalSource.Play();

        Invoke(nameof(StopGoalSound), goalSoundTime);   // stop after a few seconds
    }

    void StopGoalSound()
    {
        goalSource.Stop();
    }

    void Play(AudioClip clip)
    {
        if (clip != null) source.PlayOneShot(clip);
    }
}